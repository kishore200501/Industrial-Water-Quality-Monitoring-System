-- Create industries table
CREATE TABLE public.industries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  location TEXT,
  industry_type TEXT,
  registration_number TEXT UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create sensor_readings table
CREATE TABLE public.sensor_readings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  industry_id UUID NOT NULL REFERENCES public.industries(id) ON DELETE CASCADE,
  ph_value DECIMAL(4,2) NOT NULL,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  device_id TEXT,
  is_violation BOOLEAN NOT NULL DEFAULT false
);

-- Create violations table for fine calculations
CREATE TABLE public.violations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  industry_id UUID NOT NULL REFERENCES public.industries(id) ON DELETE CASCADE,
  reading_id UUID NOT NULL REFERENCES public.sensor_readings(id) ON DELETE CASCADE,
  ph_value DECIMAL(4,2) NOT NULL,
  safe_limit_min DECIMAL(4,2) NOT NULL DEFAULT 6.5,
  safe_limit_max DECIMAL(4,2) NOT NULL DEFAULT 8.5,
  deviation DECIMAL(4,2) NOT NULL,
  violation_level TEXT NOT NULL,
  rate_per_unit DECIMAL(10,2) NOT NULL,
  duration_hours INTEGER NOT NULL DEFAULT 1,
  fine_amount DECIMAL(12,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.industries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sensor_readings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.violations ENABLE ROW LEVEL SECURITY;

-- Public read policies for dashboard display
CREATE POLICY "Industries are publicly readable" ON public.industries FOR SELECT USING (true);
CREATE POLICY "Sensor readings are publicly readable" ON public.sensor_readings FOR SELECT USING (true);
CREATE POLICY "Violations are publicly readable" ON public.violations FOR SELECT USING (true);

-- Allow insert from edge functions (service role)
CREATE POLICY "Allow insert via service role" ON public.industries FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow insert via service role" ON public.sensor_readings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow insert via service role" ON public.violations FOR INSERT WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX idx_sensor_readings_industry ON public.sensor_readings(industry_id);
CREATE INDEX idx_sensor_readings_recorded_at ON public.sensor_readings(recorded_at DESC);
CREATE INDEX idx_violations_industry ON public.violations(industry_id);
CREATE INDEX idx_violations_status ON public.violations(status);