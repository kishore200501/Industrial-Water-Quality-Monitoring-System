import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// pH safe limits
const SAFE_PH_MIN = 6.5;
const SAFE_PH_MAX = 8.5;

// Fine rates based on violation severity
const FINE_RATES = {
  minor: 500,      // 0.5-1.0 deviation
  moderate: 1500,  // 1.0-2.0 deviation
  severe: 5000,    // 2.0-3.0 deviation
  critical: 15000  // >3.0 deviation
};

function getViolationLevel(deviation: number): { level: string; rate: number } {
  const absDeviation = Math.abs(deviation);
  if (absDeviation <= 1.0) return { level: 'minor', rate: FINE_RATES.minor };
  if (absDeviation <= 2.0) return { level: 'moderate', rate: FINE_RATES.moderate };
  if (absDeviation <= 3.0) return { level: 'severe', rate: FINE_RATES.severe };
  return { level: 'critical', rate: FINE_RATES.critical };
}

function calculateDeviation(phValue: number): number {
  if (phValue < SAFE_PH_MIN) return phValue - SAFE_PH_MIN;
  if (phValue > SAFE_PH_MAX) return phValue - SAFE_PH_MAX;
  return 0;
}

function calculateFine(deviation: number, rate: number, durationHours: number = 1): number {
  return Math.abs(deviation) * rate * durationHours;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json();
    console.log('Received sensor data:', JSON.stringify(body));

    // Validate required fields
    const { industry_id, ph_value, device_id, duration_hours = 1 } = body;

    if (!industry_id) {
      console.error('Missing industry_id');
      return new Response(
        JSON.stringify({ error: 'Missing required field: industry_id' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (ph_value === undefined || ph_value === null) {
      console.error('Missing ph_value');
      return new Response(
        JSON.stringify({ error: 'Missing required field: ph_value' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate pH is within physical range (0-14)
    const phNum = parseFloat(ph_value);
    if (isNaN(phNum) || phNum < 0 || phNum > 14) {
      console.error('Invalid pH value:', ph_value);
      return new Response(
        JSON.stringify({ error: 'Invalid pH value. Must be between 0 and 14' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if industry exists
    const { data: industry, error: industryError } = await supabase
      .from('industries')
      .select('id, name')
      .eq('id', industry_id)
      .maybeSingle();

    if (industryError) {
      console.error('Error fetching industry:', industryError);
      return new Response(
        JSON.stringify({ error: 'Database error while validating industry' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!industry) {
      console.error('Industry not found:', industry_id);
      return new Response(
        JSON.stringify({ error: 'Industry not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Calculate deviation and check for violation
    const deviation = calculateDeviation(phNum);
    const isViolation = deviation !== 0;

    console.log(`pH: ${phNum}, Deviation: ${deviation}, Is Violation: ${isViolation}`);

    // Insert sensor reading
    const { data: reading, error: readingError } = await supabase
      .from('sensor_readings')
      .insert({
        industry_id,
        ph_value: phNum,
        device_id: device_id || null,
        is_violation: isViolation
      })
      .select()
      .single();

    if (readingError) {
      console.error('Error inserting sensor reading:', readingError);
      return new Response(
        JSON.stringify({ error: 'Failed to save sensor reading' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Sensor reading saved:', reading.id);

    let violationData = null;

    // If violation, calculate and store fine
    if (isViolation) {
      const { level, rate } = getViolationLevel(deviation);
      const fineAmount = calculateFine(deviation, rate, duration_hours);

      console.log(`Violation detected! Level: ${level}, Rate: ${rate}, Fine: ${fineAmount}`);

      const { data: violation, error: violationError } = await supabase
        .from('violations')
        .insert({
          industry_id,
          reading_id: reading.id,
          ph_value: phNum,
          safe_limit_min: SAFE_PH_MIN,
          safe_limit_max: SAFE_PH_MAX,
          deviation: Math.abs(deviation),
          violation_level: level,
          rate_per_unit: rate,
          duration_hours,
          fine_amount: fineAmount,
          status: 'pending'
        })
        .select()
        .single();

      if (violationError) {
        console.error('Error inserting violation:', violationError);
        return new Response(
          JSON.stringify({ error: 'Failed to save violation record' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      violationData = violation;
      console.log('Violation recorded:', violation.id);
    }

    return new Response(
      JSON.stringify({
        success: true,
        reading: {
          id: reading.id,
          ph_value: phNum,
          is_violation: isViolation,
          recorded_at: reading.recorded_at
        },
        violation: violationData ? {
          id: violationData.id,
          level: violationData.violation_level,
          fine_amount: violationData.fine_amount,
          status: violationData.status
        } : null,
        message: isViolation 
          ? `Violation detected! Fine of ₹${violationData?.fine_amount.toLocaleString()} calculated.`
          : 'pH reading within safe limits.'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Unexpected error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
