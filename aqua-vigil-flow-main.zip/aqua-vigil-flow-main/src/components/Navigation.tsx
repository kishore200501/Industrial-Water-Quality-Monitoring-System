import { NavLink } from "@/components/NavLink";
import { Button } from "@/components/ui/button";
import { Droplet, Home, Activity, Calculator, BarChart3, Shield } from "lucide-react";

const Navigation = () => {
  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <NavLink to="/" className="flex items-center gap-2 font-bold text-xl text-foreground hover:text-primary transition-colors">
            <Droplet className="h-6 w-6 text-primary" />
            <span className="hidden sm:inline">Water Quality Monitor</span>
          </NavLink>

          {/* Navigation Links */}
          <div className="flex items-center gap-1">
            <NavLink
              to="/"
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              activeClassName="text-primary bg-primary/10"
            >
              <Home className="h-4 w-4" />
              <span className="hidden md:inline">Home</span>
            </NavLink>

            <NavLink
              to="/dashboard"
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              activeClassName="text-primary bg-primary/10"
            >
              <Activity className="h-4 w-4" />
              <span className="hidden md:inline">Dashboard</span>
            </NavLink>

            <NavLink
              to="/fines"
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              activeClassName="text-primary bg-primary/10"
            >
              <Calculator className="h-4 w-4" />
              <span className="hidden md:inline">Fines</span>
            </NavLink>

            <NavLink
              to="/reports"
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              activeClassName="text-primary bg-primary/10"
            >
              <BarChart3 className="h-4 w-4" />
              <span className="hidden md:inline">Reports</span>
            </NavLink>

            <NavLink
              to="/admin"
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              activeClassName="text-primary bg-primary/10"
            >
              <Shield className="h-4 w-4" />
              <span className="hidden md:inline">Admin</span>
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
