import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Droplet, AlertTriangle, FileText, Activity } from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center space-y-6 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
            <Droplet className="h-4 w-4" />
            IoT-Powered Water Quality Monitoring
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
            Industrial Water Quality
            <span className="bg-gradient-primary bg-clip-text text-transparent"> Monitoring System</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real-time pH monitoring and automated fine imposition system for industries, 
            ensuring environmental compliance and water quality standards.
          </p>
          <div className="flex flex-wrap gap-4 justify-center pt-4">
            <Button asChild size="lg" className="bg-gradient-primary shadow-elevated hover:opacity-90">
              <Link to="/dashboard">
                <Activity className="mr-2 h-5 w-5" />
                View Live Data
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/fines">
                Check Fine Status
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-2 hover:shadow-card transition-shadow">
            <CardHeader>
              <Activity className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Real-Time Monitoring</CardTitle>
              <CardDescription>
                Continuous pH level tracking with IoT sensors
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:shadow-card transition-shadow">
            <CardHeader>
              <AlertTriangle className="h-8 w-8 text-warning mb-2" />
              <CardTitle>Auto Fine Generation</CardTitle>
              <CardDescription>
                Automatic calculation when pollution limits are exceeded
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:shadow-card transition-shadow">
            <CardHeader>
              <FileText className="h-8 w-8 text-success mb-2" />
              <CardTitle>Detailed Reports</CardTitle>
              <CardDescription>
                Comprehensive analytics and violation history
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:shadow-card transition-shadow">
            <CardHeader>
              <Droplet className="h-8 w-8 text-accent mb-2" />
              <CardTitle>Compliance Tracking</CardTitle>
              <CardDescription>
                Monitor industrial adherence to water standards
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">How It Works</h2>
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold">1</span>
                  pH Sensor Monitoring
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  IoT-enabled pH sensors continuously monitor industrial water discharge, 
                  sending real-time data to the cloud platform.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold">2</span>
                  Threshold Detection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  System automatically compares readings against safe ranges (pH 6.5-8.5). 
                  Violations trigger immediate alerts.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <span className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold">3</span>
                  Fine Calculation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Automated fine calculation based on violation severity, duration, and 
                  predefined penalty rates with instant report generation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="border-2 bg-gradient-primary text-primary-foreground">
          <CardContent className="p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Monitor Water Quality?</h2>
            <p className="text-lg mb-6 opacity-90">
              Start tracking industrial compliance and environmental protection today.
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild size="lg" variant="secondary">
                <Link to="/dashboard">Access Dashboard</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                <Link to="/reports">View Reports</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
};

export default Home;
