import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Users, Bell, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Admin = () => {
  const { toast } = useToast();

  const industries = [
    { id: 1, name: "ABC Chemicals Ltd.", location: "Zone A", status: "active", sensors: 3 },
    { id: 2, name: "XYZ Textiles Pvt. Ltd.", location: "Zone B", status: "active", sensors: 2 },
    { id: 3, name: "PQR Pharmaceuticals", location: "Zone C", status: "warning", sensors: 4 },
    { id: 4, name: "LMN Steel Works", location: "Zone D", status: "active", sensors: 3 },
  ];

  const pendingReports = [
    { id: "R001", industry: "ABC Chemicals", amount: 29250, status: "pending", date: "2024-01-15" },
    { id: "R002", industry: "PQR Pharma", amount: 15680, status: "pending", date: "2024-01-14" },
  ];

  const handleSaveThreshold = () => {
    toast({
      title: "Thresholds Updated",
      description: "Pollution threshold limits have been successfully updated.",
    });
  };

  const handleApprove = (id: string) => {
    toast({
      title: "Report Approved",
      description: `Fine report ${id} has been approved and sent for processing.`,
    });
  };

  const handleReject = (id: string) => {
    toast({
      title: "Report Rejected",
      description: `Fine report ${id} has been rejected.`,
      variant: "destructive",
    });
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground flex items-center gap-3">
            <Shield className="h-10 w-10 text-primary" />
            Admin Control Panel
          </h1>
          <p className="text-muted-foreground mt-2">Manage system settings and approvals</p>
        </div>

        <Tabs defaultValue="industries" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="industries" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Industries
            </TabsTrigger>
            <TabsTrigger value="thresholds" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Thresholds
            </TabsTrigger>
            <TabsTrigger value="approvals" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Approvals
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              System Logs
            </TabsTrigger>
          </TabsList>

          {/* Industries Management */}
          <TabsContent value="industries">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Manage Industry Profiles</CardTitle>
                <CardDescription>View and manage registered industrial units</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Industry Name</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Active Sensors</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {industries.map((industry) => (
                      <TableRow key={industry.id}>
                        <TableCell className="font-medium">{industry.name}</TableCell>
                        <TableCell>{industry.location}</TableCell>
                        <TableCell>{industry.sensors}</TableCell>
                        <TableCell>
                          <Badge variant={industry.status === "active" ? "default" : "warning"}>
                            {industry.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">Edit</Button>
                            <Button size="sm" variant="outline">View Details</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-4">
                  <Button className="bg-gradient-primary">
                    <Users className="mr-2 h-4 w-4" />
                    Add New Industry
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Threshold Settings */}
          <TabsContent value="thresholds">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-2">
                <CardHeader>
                  <CardTitle>pH Thresholds</CardTitle>
                  <CardDescription>Set safe pH limits for water quality</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="min-ph">Minimum Safe pH Level</Label>
                    <Input id="min-ph" type="number" defaultValue="6.5" step="0.1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max-ph">Maximum Safe pH Level</Label>
                    <Input id="max-ph" type="number" defaultValue="8.5" step="0.1" />
                  </div>
                  <Button onClick={handleSaveThreshold} className="w-full">Save pH Thresholds</Button>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardHeader>
                  <CardTitle>Fine Rate Configuration</CardTitle>
                  <CardDescription>Set penalty rates for violations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="critical-rate">Critical Violation Rate (₹/hour)</Label>
                    <Input id="critical-rate" type="number" defaultValue="5000" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="high-rate">High Violation Rate (₹/hour)</Label>
                    <Input id="high-rate" type="number" defaultValue="3500" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="moderate-rate">Moderate Violation Rate (₹/hour)</Label>
                    <Input id="moderate-rate" type="number" defaultValue="2000" />
                  </div>
                  <Button onClick={handleSaveThreshold} className="w-full">Save Fine Rates</Button>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardHeader>
                  <CardTitle>Additional Parameters</CardTitle>
                  <CardDescription>Configure other water quality thresholds</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="tds">TDS Limit (ppm)</Label>
                    <Input id="tds" type="number" defaultValue="500" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bod">BOD Limit (mg/L)</Label>
                    <Input id="bod" type="number" defaultValue="30" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cod">COD Limit (mg/L)</Label>
                    <Input id="cod" type="number" defaultValue="250" />
                  </div>
                  <Button onClick={handleSaveThreshold} className="w-full">Save Parameters</Button>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardHeader>
                  <CardTitle>Alert Settings</CardTitle>
                  <CardDescription>Configure notification thresholds</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="alert-threshold">Alert Trigger Deviation</Label>
                    <Input id="alert-threshold" type="number" defaultValue="0.5" step="0.1" />
                    <p className="text-xs text-muted-foreground">Send alerts when pH deviates by this amount</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notification-email">Notification Email</Label>
                    <Input id="notification-email" type="email" defaultValue="admin@waterquality.gov" />
                  </div>
                  <Button onClick={handleSaveThreshold} className="w-full">Save Alert Settings</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Fine Report Approvals */}
          <TabsContent value="approvals">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Pending Fine Report Approvals</CardTitle>
                <CardDescription>Review and approve fine reports before processing</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Report ID</TableHead>
                      <TableHead>Industry</TableHead>
                      <TableHead>Fine Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingReports.map((report) => (
                      <TableRow key={report.id}>
                        <TableCell className="font-mono">{report.id}</TableCell>
                        <TableCell>{report.industry}</TableCell>
                        <TableCell className="font-bold">₹{report.amount.toLocaleString()}</TableCell>
                        <TableCell>{new Date(report.date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge variant="warning">PENDING</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleApprove(report.id)}
                              className="bg-success hover:bg-success/90"
                            >
                              Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleReject(report.id)}
                            >
                              Reject
                            </Button>
                            <Button size="sm" variant="outline">Details</Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Logs */}
          <TabsContent value="logs">
            <Card className="border-2">
              <CardHeader>
                <CardTitle>System Activity Logs</CardTitle>
                <CardDescription>Recent system events and notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { time: "2024-01-15 14:32", event: "Critical pH violation detected", location: "ABC Chemicals - Zone A", severity: "high" },
                    { time: "2024-01-15 13:15", event: "Fine report approved", location: "XYZ Textiles - Zone B", severity: "normal" },
                    { time: "2024-01-15 12:05", event: "Sensor calibration completed", location: "PQR Pharma - Zone C", severity: "normal" },
                    { time: "2024-01-15 11:20", event: "Threshold settings updated", location: "System Admin", severity: "normal" },
                    { time: "2024-01-15 10:45", event: "New industry registered", location: "LMN Steel Works - Zone D", severity: "normal" },
                  ].map((log, index) => (
                    <div key={index} className="flex items-start justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="space-y-1">
                        <p className="font-medium">{log.event}</p>
                        <p className="text-sm text-muted-foreground">{log.location}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <Badge variant={log.severity === "high" ? "destructive" : "secondary"}>
                          {log.severity.toUpperCase()}
                        </Badge>
                        <p className="text-xs text-muted-foreground">{log.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
