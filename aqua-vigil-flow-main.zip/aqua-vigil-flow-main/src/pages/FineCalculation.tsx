import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { FileText, Download, Send, AlertTriangle, Calculator } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Violation {
  id: string;
  industryName: string;
  location: string;
  phValue: number;
  safeLimit: number;
  violationLevel: string;
  duration: number; // in hours
  ratePerHour: number;
  fineAmount: number;
  timestamp: string;
}

const FineCalculation = () => {
  const { toast } = useToast();
  const [violations] = useState<Violation[]>([
    {
      id: "V001",
      industryName: "ABC Chemicals Ltd.",
      location: "Industrial Area - Zone A, Outlet 3",
      phValue: 9.8,
      safeLimit: 8.5,
      violationLevel: "Critical",
      duration: 4.5,
      ratePerHour: 5000,
      fineAmount: 29250,
      timestamp: new Date().toISOString(),
    },
    {
      id: "V002",
      industryName: "XYZ Textiles Pvt. Ltd.",
      location: "Industrial Area - Zone B, Outlet 1",
      phValue: 5.8,
      safeLimit: 6.5,
      violationLevel: "High",
      duration: 2.3,
      ratePerHour: 3500,
      fineAmount: 5635,
      timestamp: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: "V003",
      industryName: "PQR Pharmaceuticals",
      location: "Industrial Area - Zone C, Outlet 2",
      phValue: 8.9,
      safeLimit: 8.5,
      violationLevel: "Moderate",
      duration: 1.2,
      ratePerHour: 2000,
      fineAmount: 960,
      timestamp: new Date(Date.now() - 7200000).toISOString(),
    },
  ]);

  const calculateFine = (phValue: number, safeLimit: number, duration: number, rate: number) => {
    const deviation = Math.abs(phValue - safeLimit);
    return Math.round(deviation * rate * duration);
  };

  const getViolationColor = (level: string) => {
    switch (level) {
      case "Critical": return "destructive";
      case "High": return "warning";
      case "Moderate": return "secondary";
      default: return "default";
    }
  };

  const handleDownloadReport = (violation: Violation) => {
    toast({
      title: "Downloading Report",
      description: `Fine report for ${violation.industryName} is being generated.`,
    });
  };

  const handleSendToAuthority = (violation: Violation) => {
    toast({
      title: "Report Sent",
      description: `Fine report sent to environmental authority for ${violation.industryName}.`,
    });
  };

  const totalFines = violations.reduce((sum, v) => sum + v.fineAmount, 0);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-foreground flex items-center gap-3">
            <Calculator className="h-10 w-10 text-primary" />
            Fine Calculation & Management
          </h1>
          <p className="text-muted-foreground mt-2">Automated fine calculation for pollution violations</p>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Total Violations</CardDescription>
              <CardTitle className="text-3xl font-bold text-destructive">{violations.length}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Total Fines Imposed</CardDescription>
              <CardTitle className="text-3xl font-bold text-foreground">₹{totalFines.toLocaleString()}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Critical Violations</CardDescription>
              <CardTitle className="text-3xl font-bold text-destructive">
                {violations.filter(v => v.violationLevel === "Critical").length}
              </CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Average Fine Amount</CardDescription>
              <CardTitle className="text-3xl font-bold text-primary">
                ₹{Math.round(totalFines / violations.length).toLocaleString()}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Violation Details */}
        {violations.map((violation) => (
          <Card key={violation.id} className="border-2 shadow-card">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-2xl flex items-center gap-3">
                    {violation.industryName}
                    <Badge variant={getViolationColor(violation.violationLevel)}>
                      {violation.violationLevel} Violation
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-base">
                    Violation ID: {violation.id} | Location: {violation.location}
                  </CardDescription>
                </div>
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Violation Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Recorded pH Value</p>
                  <p className="text-2xl font-bold text-foreground">{violation.phValue}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Safe Limit</p>
                  <p className="text-2xl font-bold text-success">{violation.safeLimit}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Deviation</p>
                  <p className="text-2xl font-bold text-destructive">
                    {Math.abs(violation.phValue - violation.safeLimit).toFixed(2)}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Violation Duration</p>
                  <p className="text-2xl font-bold text-foreground">{violation.duration} hrs</p>
                </div>
              </div>

              <Separator />

              {/* Fine Calculation Breakdown */}
              <div className="bg-muted/50 p-6 rounded-lg space-y-3">
                <h3 className="font-semibold text-lg mb-4">Fine Calculation Breakdown</h3>
                <Table>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Deviation from Safe Limit</TableCell>
                      <TableCell className="text-right">
                        {Math.abs(violation.phValue - violation.safeLimit).toFixed(2)} pH units
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Rate per Hour</TableCell>
                      <TableCell className="text-right">₹{violation.ratePerHour.toLocaleString()}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Duration of Violation</TableCell>
                      <TableCell className="text-right">{violation.duration} hours</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Calculation Formula</TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        |pH - Safe Limit| × Rate × Duration
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-t-2">
                      <TableCell className="font-bold text-lg">Total Fine Amount</TableCell>
                      <TableCell className="text-right font-bold text-2xl text-destructive">
                        ₹{violation.fineAmount.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              {/* Timestamp and Actions */}
              <div className="flex items-center justify-between pt-4">
                <p className="text-sm text-muted-foreground">
                  Detected: {new Date(violation.timestamp).toLocaleString()}
                </p>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => handleDownloadReport(violation)}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download PDF
                  </Button>
                  <Button
                    onClick={() => handleSendToAuthority(violation)}
                    className="bg-gradient-primary"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send to Authority
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Summary Card */}
        <Card className="border-2 bg-gradient-primary text-primary-foreground">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-2">Total Fines Summary</h3>
                <p className="opacity-90">
                  {violations.length} violation{violations.length !== 1 ? 's' : ''} detected with automated fine calculation
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm opacity-75 mb-1">Grand Total</p>
                <p className="text-5xl font-bold">₹{totalFines.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FineCalculation;
