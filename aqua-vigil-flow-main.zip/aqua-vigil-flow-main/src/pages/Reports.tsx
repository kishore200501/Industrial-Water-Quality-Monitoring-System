import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { FileDown, FileSpreadsheet, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Reports = () => {
  const { toast } = useToast();

  // Sample data for charts
  const monthlyTrend = [
    { month: "Jan", violations: 12, fines: 145000 },
    { month: "Feb", violations: 8, fines: 98000 },
    { month: "Mar", violations: 15, fines: 187000 },
    { month: "Apr", violations: 10, fines: 125000 },
    { month: "May", violations: 18, fines: 215000 },
    { month: "Jun", violations: 14, fines: 168000 },
  ];

  const industryData = [
    { name: "ABC Chemicals", fines: 340000, violations: 12 },
    { name: "XYZ Textiles", fines: 280000, violations: 9 },
    { name: "PQR Pharma", fines: 195000, violations: 7 },
    { name: "LMN Steel", fines: 420000, violations: 15 },
    { name: "DEF Foods", fines: 125000, violations: 4 },
  ];

  const violationTypes = [
    { name: "Critical (pH > 9.5)", value: 35, color: "hsl(var(--destructive))" },
    { name: "High (pH 8.5-9.5)", value: 28, color: "hsl(var(--warning))" },
    { name: "Moderate (pH 8.0-8.5)", value: 22, color: "hsl(var(--accent))" },
    { name: "Low pH (< 6.5)", value: 15, color: "hsl(var(--primary))" },
  ];

  const avgPHData = [
    { month: "Jan", avgPH: 7.4 },
    { month: "Feb", avgPH: 7.2 },
    { month: "Mar", avgPH: 7.6 },
    { month: "Apr", avgPH: 7.3 },
    { month: "May", avgPH: 7.8 },
    { month: "Jun", avgPH: 7.5 },
  ];

  const handleExport = (format: string) => {
    toast({
      title: "Exporting Report",
      description: `Your report is being exported as ${format.toUpperCase()}.`,
    });
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground flex items-center gap-3">
              <TrendingUp className="h-10 w-10 text-primary" />
              Reports & Analytics
            </h1>
            <p className="text-muted-foreground mt-2">Comprehensive pollution and fine analysis</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => handleExport("pdf")}>
              <FileDown className="mr-2 h-4 w-4" />
              Export PDF
            </Button>
            <Button variant="outline" onClick={() => handleExport("excel")}>
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Export Excel
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Filter Reports</CardTitle>
            <CardDescription>Select criteria to filter analytical data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Select defaultValue="all">
                <SelectTrigger>
                  <SelectValue placeholder="Select Industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  <SelectItem value="abc">ABC Chemicals</SelectItem>
                  <SelectItem value="xyz">XYZ Textiles</SelectItem>
                  <SelectItem value="pqr">PQR Pharma</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="2024">
                <SelectTrigger>
                  <SelectValue placeholder="Select Year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all">
                <SelectTrigger>
                  <SelectValue placeholder="Violation Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                </SelectContent>
              </Select>

              <Button className="bg-gradient-primary">Apply Filters</Button>
            </div>
          </CardContent>
        </Card>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Monthly Pollution Trend */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Monthly Violation Trend</CardTitle>
              <CardDescription>Number of violations per month (Last 6 months)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="violations" fill="hsl(var(--primary))" name="Violations" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Violation Types Distribution */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Violation Types Distribution</CardTitle>
              <CardDescription>Breakdown by violation severity</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={violationTypes}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {violationTypes.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Industries with Most Fines */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Industries with Most Fines</CardTitle>
              <CardDescription>Top violators by total fine amount</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={industryData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                  <YAxis dataKey="name" type="category" stroke="hsl(var(--muted-foreground))" width={120} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                    formatter={(value: any) => `₹${value.toLocaleString()}`}
                  />
                  <Bar dataKey="fines" fill="hsl(var(--destructive))" name="Fine Amount (₹)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Average pH Trend */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle>Average pH Level Trend</CardTitle>
              <CardDescription>Monthly average pH levels across all sensors</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={avgPHData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                  <YAxis domain={[0, 14]} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="avgPH" 
                    stroke="hsl(var(--success))" 
                    strokeWidth={3}
                    name="Average pH"
                    dot={{ fill: "hsl(var(--success))", r: 5 }}
                  />
                  <Line dataKey={() => 6.5} stroke="hsl(var(--muted-foreground))" strokeDasharray="5 5" name="Lower Limit" />
                  <Line dataKey={() => 8.5} stroke="hsl(var(--muted-foreground))" strokeDasharray="5 5" name="Upper Limit" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Summary Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-2">
            <CardHeader>
              <CardDescription>Total Violations (6 months)</CardDescription>
              <CardTitle className="text-3xl font-bold text-foreground">77</CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardDescription>Total Fines Collected</CardDescription>
              <CardTitle className="text-3xl font-bold text-success">₹938,000</CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardDescription>Average Fine per Violation</CardDescription>
              <CardTitle className="text-3xl font-bold text-primary">₹12,182</CardTitle>
            </CardHeader>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardDescription>Compliance Rate</CardDescription>
              <CardTitle className="text-3xl font-bold text-accent">87.3%</CardTitle>
            </CardHeader>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Reports;
