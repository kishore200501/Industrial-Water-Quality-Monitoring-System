import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Activity, AlertTriangle, TrendingUp, Droplet } from "lucide-react";
import { Link } from "react-router-dom";

interface SensorReading {
  id: string;
  timestamp: string;
  phValue: number;
  location: string;
  status: "safe" | "warning" | "danger";
}

const Dashboard = () => {
  const [currentPH, setCurrentPH] = useState(7.2);
  const [readings, setReadings] = useState<SensorReading[]>([
    { id: "1", timestamp: new Date().toISOString(), phValue: 7.2, location: "Industry A - Outlet 1", status: "safe" },
    { id: "2", timestamp: new Date(Date.now() - 300000).toISOString(), phValue: 7.5, location: "Industry B - Outlet 2", status: "safe" },
    { id: "3", timestamp: new Date(Date.now() - 600000).toISOString(), phValue: 9.1, location: "Industry C - Outlet 3", status: "danger" },
    { id: "4", timestamp: new Date(Date.now() - 900000).toISOString(), phValue: 8.2, location: "Industry A - Outlet 1", status: "warning" },
  ]);

  const [chartData, setChartData] = useState([
    { time: "10:00", ph: 7.0 },
    { time: "10:05", ph: 7.2 },
    { time: "10:10", ph: 7.4 },
    { time: "10:15", ph: 7.3 },
    { time: "10:20", ph: 7.2 },
    { time: "10:25", ph: currentPH },
  ]);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newPH = parseFloat((6.5 + Math.random() * 2.5).toFixed(2));
      setCurrentPH(newPH);
      
      const newReading: SensorReading = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        phValue: newPH,
        location: "Industry A - Outlet 1",
        status: newPH < 6.5 || newPH > 8.5 ? "danger" : newPH < 7.0 || newPH > 8.0 ? "warning" : "safe"
      };
      
      setReadings(prev => [newReading, ...prev.slice(0, 9)]);
      
      const now = new Date();
      const timeStr = now.getHours() + ":" + String(now.getMinutes()).padStart(2, '0');
      setChartData(prev => [...prev.slice(1), { time: timeStr, ph: newPH }]);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "safe": return "success";
      case "warning": return "warning";
      case "danger": return "destructive";
      default: return "secondary";
    }
  };

  const getPHStatus = (ph: number) => {
    if (ph < 6.5 || ph > 8.5) return { status: "danger", label: "Critical", icon: AlertTriangle };
    if (ph < 7.0 || ph > 8.0) return { status: "warning", label: "Warning", icon: TrendingUp };
    return { status: "safe", label: "Safe", icon: Activity };
  };

  const phStatus = getPHStatus(currentPH);
  const StatusIcon = phStatus.icon;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Live Monitoring Dashboard</h1>
            <p className="text-muted-foreground mt-2">Real-time water quality monitoring system</p>
          </div>
          <Button asChild className="bg-gradient-primary shadow-elevated">
            <Link to="/fines">
              <AlertTriangle className="mr-2 h-4 w-4" />
              Generate Fine
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Current pH Level</CardDescription>
              <CardTitle className="text-4xl font-bold flex items-baseline gap-2">
                {currentPH.toFixed(2)}
                <Badge variant={getStatusColor(phStatus.status)} className="text-sm">
                  {phStatus.label}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-muted-foreground">
                <StatusIcon className="h-4 w-4" />
                <span className="text-sm">Updated just now</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Safe Range</CardDescription>
              <CardTitle className="text-3xl font-bold text-success">6.5 - 8.5</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Droplet className="h-4 w-4" />
                <span className="text-sm">Standard pH limits</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Active Sensors</CardDescription>
              <CardTitle className="text-3xl font-bold text-primary">8</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Activity className="h-4 w-4" />
                <span className="text-sm">All operational</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardDescription>Violations Today</CardDescription>
              <CardTitle className="text-3xl font-bold text-destructive">3</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-muted-foreground">
                <AlertTriangle className="h-4 w-4" />
                <span className="text-sm">Requires attention</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* pH Gauge - Visual Representation */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>pH Level Monitor</CardTitle>
            <CardDescription>Real-time pH measurement with status indicator</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8">
              <div className="relative w-64 h-64">
                {/* Circular gauge */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
                  {/* Background circle */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="hsl(var(--muted))"
                    strokeWidth="20"
                  />
                  {/* Colored segments */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="hsl(var(--destructive))"
                    strokeWidth="20"
                    strokeDasharray="133 400"
                    strokeDashoffset="0"
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="hsl(var(--success))"
                    strokeWidth="20"
                    strokeDasharray="133 400"
                    strokeDashoffset="-133"
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="hsl(var(--destructive))"
                    strokeWidth="20"
                    strokeDasharray="133 400"
                    strokeDashoffset="-266"
                  />
                  {/* Current value indicator */}
                  <circle
                    cx="100"
                    cy="100"
                    r="85"
                    fill="none"
                    stroke="hsl(var(--primary))"
                    strokeWidth="24"
                    strokeDasharray={`${((currentPH - 0) / 14) * 534} 534`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-5xl font-bold text-foreground">{currentPH.toFixed(2)}</span>
                  <span className="text-sm text-muted-foreground mt-2">pH Level</span>
                  <Badge variant={getStatusColor(phStatus.status)} className="mt-3">
                    {phStatus.label}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex justify-center gap-6 mt-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive"></div>
                <span className="text-muted-foreground">Acidic (&lt; 6.5)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-success"></div>
                <span className="text-muted-foreground">Safe (6.5 - 8.5)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive"></div>
                <span className="text-muted-foreground">Alkaline (&gt; 8.5)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trend Chart */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>pH Trend Analysis</CardTitle>
            <CardDescription>Last 30 minutes of pH readings</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" />
                <YAxis domain={[0, 14]} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)",
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="ph" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  dot={{ fill: "hsl(var(--primary))", r: 5 }}
                  activeDot={{ r: 7 }}
                />
                {/* Safe zone reference lines */}
                <Line dataKey={() => 6.5} stroke="hsl(var(--success))" strokeDasharray="5 5" dot={false} />
                <Line dataKey={() => 8.5} stroke="hsl(var(--success))" strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Readings Table */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Recent Sensor Readings</CardTitle>
            <CardDescription>Latest measurements from all monitoring points</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>pH Value</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {readings.map((reading) => (
                  <TableRow key={reading.id}>
                    <TableCell className="font-mono text-sm">
                      {new Date(reading.timestamp).toLocaleString()}
                    </TableCell>
                    <TableCell>{reading.location}</TableCell>
                    <TableCell className="font-bold">{reading.phValue.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(reading.status)}>
                        {reading.status.toUpperCase()}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
